/* global jQuery */
(function ($) {
  $(function () {
    // Nếu không phải trang settings của plugin, thoát sớm (phòng trường hợp enqueue nhầm)
    if (!$('#scb-bg-type').length) return;

    // WP Color Picker (nếu có)
    if ($.fn.wpColorPicker) {
      $('.scb-color-picker').wpColorPicker();
    }

    const $bgType        = $('#scb-bg-type');
    const $rowGradient   = $('#scb-gradient-row');
    const $rowAngle      = $('#scb-angle-row');

    const $timeMode      = $('input[name="scb_options[time_mode]"]');
    const $rowDeadline   = $('#scb-deadline-row');

    const $closeMode     = $('input[name="scb_options[close_mode]"]');
    const $rowDuration   = $('#scb-duration-row');

    // Helpers
    function show($el){ $el.attr('aria-hidden', 'false').show(); }
    function hide($el){ $el.attr('aria-hidden', 'true').hide(); }

    function refreshBgRows() {
      const type = $bgType.val();
      if (type === 'solid') {
        hide($rowGradient); hide($rowAngle);
      } else if (type === 'linear') {
        show($rowGradient); show($rowAngle);
      } else { // radial
        show($rowGradient); hide($rowAngle);
      }
    }

    function refreshDeadlineRow() {
      const mode = $timeMode.filter(':checked').val();
      if (mode === 'fixed') show($rowDeadline);
      else hide($rowDeadline);
    }

    function refreshDurationRow() {
      const mode = $closeMode.filter(':checked').val();
      if (mode === 'permanent') show($rowDuration);
      else hide($rowDuration);
    }

    // Bind events
    $bgType.on('change', refreshBgRows);
    $timeMode.on('change', refreshDeadlineRow);
    $closeMode.on('change', refreshDurationRow);

    // Initial state (sau khi DOM & color picker sẵn sàng)
    refreshBgRows();
    refreshDeadlineRow();
    refreshDurationRow();
  });
})(jQuery);

/* global SCB_DATA */
(function () {
  if (typeof SCB_DATA === 'undefined') return;

  // ====== Config từ PHP ======
  const TIME_MODE        = SCB_DATA.timeMode || 'fixed';           // 'fixed' | 'hourly'
  const FIXED_DEADLINE_UTC = Number(SCB_DATA.deadlineUtc || 0);    // ms
  const TZ_OFFSET_MS     = Number(SCB_DATA.tzOffsetMs || 0);       // UTC+7 => 7*3600*1000

  let POSITION = SCB_DATA.position === 'bottom' ? 'bottom' : 'top';
  let FIXED    = !!SCB_DATA.positionFixed;

  const CLOSE_MODE     = SCB_DATA.closeMode || 'session';          // 'none' | 'session' | 'permanent'
  const CLOSE_DURATION = Number(SCB_DATA.closeDuration || 0);      // ms

  // ====== DOM ======
  const bar    = document.getElementById('scb-sticky-bar');
  const spacer = document.getElementById('scb-spacer');
  if (!bar || !spacer) return;

  // Nếu chọn bottom mà không bật fixed -> cưỡng bức fixed để đảm bảo nằm dưới viewport
  if (POSITION === 'bottom' && !FIXED) {
    FIXED = true;
  }

  // ====== Store helpers (permanent close) ======
  const KEY = 'SCB_BAR_STATE';
  function getStore() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }
  function setStore(val) {
    try { localStorage.setItem(KEY, JSON.stringify(val)); } catch (_) {}
  }

  function shouldHideByCloseState() {
    if (CLOSE_MODE !== 'permanent') return false; // session: KHÔNG lưu state => luôn hiển thị khi sang trang mới
    const data = getStore();
    if (!data) return false;
    if (!data.closedAt || !CLOSE_DURATION) return !!data.closed;
    return (Date.now() - data.closedAt) < CLOSE_DURATION;
  }

  // ====== Deadline theo mode ======
  function nextHourlyDeadlineUtc() {
    // Lấy "giờ Việt Nam" = now UTC + 7h
    const nowUtcMs = Date.now();
    const local7Ms = nowUtcMs + TZ_OFFSET_MS;
    const d = new Date(local7Ms);
    d.setMilliseconds(0);
    d.setSeconds(0);
    d.setMinutes(0);
    d.setHours(d.getHours() + 1); // đầu giờ tiếp theo (UTC+7)
    // chuyển ngược về UTC
    return d.getTime() - TZ_OFFSET_MS;
  }

  let deadlineUtcMs = (TIME_MODE === 'fixed') ? FIXED_DEADLINE_UTC : nextHourlyDeadlineUtc();

  // ====== Layout + Spacer ======
  function measureAndApplySpacer() {
    if (!FIXED) { // không fixed thì không cần spacer
      spacer.style.height = '0px';
      return;
    }
    // Đợi render xong rồi đo (tránh chiều cao = 0 khi CSS/font chưa áp)
    window.requestAnimationFrame(() => {
      setTimeout(() => {
        const h = bar.getBoundingClientRect().height || 0;
        spacer.style.height = h + 'px';
      }, 0);
    });
  }

  function applyPosition() {
    bar.classList.add(POSITION === 'bottom' ? 'scb-bottom' : 'scb-top');
    if (FIXED) {
      bar.classList.add('scb-fixed');
      spacer.classList.add(POSITION === 'bottom' ? 'scb-spacer-bottom' : 'scb-spacer-top');
    } else {
      bar.classList.remove('scb-fixed');
      spacer.classList.remove('scb-spacer-bottom', 'scb-spacer-top');
    }
    measureAndApplySpacer();
  }

  function hideBar() {
    if (timer) clearInterval(timer);
    bar.style.display = 'none';
    spacer.style.height = '0px';
  }
  function showBar() { bar.style.display = ''; }

  // ====== Countdown & Effects ======
  const countdownEl = bar.querySelector('.scb-countdown');
  let lastText = ''; // để kích hoạt flip khi đổi số

  function pad2(n){ return String(n).padStart(2,'0'); }
  function formatRemain(ms) {
    if (ms <= 0) return '00:00:00';
    const sec = Math.floor(ms / 1000);
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (d > 0) return `${d}d ${pad2(h)}:${pad2(m)}:${pad2(s)}`;
    return `${pad2(h)}:${pad2(m)}:${pad2(s)}`;
  }

  const URGENCY_MS = 60 * 60 * 1000; // < 60 phút -> bounce
  function setUrgency(on){
    if (on) bar.classList.add('scb-urgency');
    else bar.classList.remove('scb-urgency');
  }

  function flipOnce(){
    if (!countdownEl) return;
    countdownEl.classList.remove('scb-flip-tick');
    // force reflow để reset animation
    // eslint-disable-next-line no-unused-expressions
    countdownEl.offsetWidth;
    countdownEl.classList.add('scb-flip-tick');
  }

  function tick() {
    let remain = deadlineUtcMs - Date.now();

    if (TIME_MODE === 'fixed') {
      if (remain <= 0) { hideBar(); return; }
    } else {
      // hourly: hết hạn thì nhảy sang đầu giờ tiếp theo
      if (remain <= 0) {
        deadlineUtcMs = nextHourlyDeadlineUtc();
        remain = deadlineUtcMs - Date.now();
      }
    }

    // Cập nhật nội dung + flip khi đổi
    if (countdownEl) {
      const nextText = formatRemain(Math.max(0, remain));
      if (nextText !== lastText) {
        countdownEl.textContent = nextText;
        lastText = nextText;
        flipOnce();
      }
    }

    // Urgency bounce
    setUrgency(remain <= URGENCY_MS);
  }

  let timer = null;

  // ====== Nút đóng ======
  const closeBtn = bar.querySelector('.scb-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      if (CLOSE_MODE === 'permanent') {
        setStore({ closed: true, closedAt: Date.now() });
      }
      // CLOSE_MODE === 'session' -> KHÔNG lưu gì => chỉ ẩn trang hiện tại
      hideBar();
    });
  }

  // ====== Khởi tạo ======
  if (shouldHideByCloseState()) { hideBar(); return; }
  if (TIME_MODE === 'fixed' && FIXED_DEADLINE_UTC <= Date.now()) { hideBar(); return; }

  applyPosition();
  showBar();

  // Entry animation: thêm .scb-enter để CSS slide-in (trên/dưới)
  requestAnimationFrame(function(){ bar.classList.add('scb-enter'); });

  tick();
  timer = setInterval(tick, 1000);

  // Reflow spacer khi resize / font tải xong / animation xong
  window.addEventListener('resize', measureAndApplySpacer);
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(measureAndApplySpacer).catch(function(){});
  }
  bar.addEventListener('animationend', measureAndApplySpacer, { passive: true });
})();

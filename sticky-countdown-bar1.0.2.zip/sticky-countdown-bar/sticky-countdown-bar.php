<?php
/**
 * Plugin Name: Sticky Countdown Bar
 * Description: Hiển thị thanh sticky trên đầu website với text link + đồng hồ đếm ngược. Hỗ trợ 2 chế độ: đến thời điểm cố định (UTC+7) hoặc luôn đếm tới đầu giờ tiếp theo (UTC+7).
 * Version:     1.2.0
 * Author:      Thái Dương 🎯
 * Author URI:  https://thanhthai.org
 * License:     GPL-2.0+
 */

if ( ! defined('ABSPATH') ) exit;

class Sticky_Countdown_Bar {
    const OPT_KEY = 'scb_options';
    const VERSION = '1.2.0';

    public function __construct() {
        add_action('admin_menu',               [$this, 'add_settings_page']);
        add_action('admin_init',               [$this, 'register_settings']);
        add_action('admin_enqueue_scripts',    [$this, 'enqueue_admin_assets']);

        // AUTO mode (Enabled): enqueue + render
        add_action('wp_enqueue_scripts',       [$this, 'enqueue_assets_auto']);
        add_action('wp_body_open',             [$this, 'render_bar_auto'], 5);

        // Shortcode: luôn hoạt động độc lập với Enabled (nếu còn hạn hoặc mode=hourly)
        add_shortcode('sticky_countdown_bar',  [$this, 'shortcode']);

        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
    }

    public static function activate() {
        $defaults = [
            // Hiển thị
            'enabled'      => 1,
            'text'         => 'Ưu đãi đặc biệt – xem ngay',
            'url'          => home_url('/'),

            // Chế độ thời gian
            // 'fixed'  = đến 1 mốc thời gian cố định (UTC+7)
            // 'hourly' = luôn đếm tới đầu giờ tiếp theo (UTC+7)
            'time_mode'    => 'fixed',
            'deadline_utc' => time() + 86400, // chỉ dùng khi time_mode = fixed

            // Nền/hiển thị
            'bg_type'      => 'solid', // solid | linear | radial
            'bg_color'     => '#111827',
            'gradient_color_2' => '#1F2937',
            'gradient_angle' => 90,
            'text_color'   => '#FFFFFF',
            'font_size_desktop' => 14,
            'font_size_mobile'  => 12,
            'padding'      => 0.6,
            'position'     => 'top', // top, bottom (UI đang ẩn, vẫn hỗ trợ qua code)
            'position_fixed' => 1,

            // Đóng thanh
            'close_mode'   => 'session', // none, session, permanent
            'close_duration' => 3600,
        ];
        $opt = get_option(self::OPT_KEY);
        if ( ! is_array($opt) ) {
            add_option(self::OPT_KEY, $defaults, '', 'no');
        } else {
            update_option(self::OPT_KEY, array_merge($defaults, $opt));
        }
    }

    public function add_settings_page() {
        add_options_page(
            'Sticky Countdown Bar',
            'Sticky Countdown Bar',
            'manage_options',
            'sticky-countdown-bar',
            [$this, 'settings_page_html']
        );
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'settings_page_sticky-countdown-bar') return;
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('scb-admin', plugin_dir_url(__FILE__) . 'assets/js/admin.js', ['jquery','wp-color-picker'], self::VERSION, true);
    }

    public function register_settings() {
        register_setting(self::OPT_KEY, self::OPT_KEY, [$this, 'sanitize_options']);
    }

    public function sanitize_options($input) {
        $out = [];

        // Bật / tắt
        $out['enabled'] = isset($input['enabled']) ? 1 : 0;

        // Văn bản, URL
        $out['text'] = isset($input['text']) ? sanitize_text_field($input['text']) : '';
        $out['url']  = isset($input['url'])  ? esc_url_raw($input['url'])        : '';

        // Chế độ thời gian
        $allowed_modes   = ['fixed','hourly'];
        $out['time_mode'] = (isset($input['time_mode']) && in_array($input['time_mode'], $allowed_modes, true)) ? $input['time_mode'] : 'fixed';

        // Khi 'fixed', parse datetime theo UTC+7 (Asia/Bangkok)
        if ($out['time_mode'] === 'fixed') {
            $deadline_local = isset($input['deadline_local']) ? sanitize_text_field($input['deadline_local']) : '';
            $out['deadline_utc'] = $this->parse_local_utc7_to_utc_ts($deadline_local);
            // Nếu quá khứ → đẩy +30 phút
            if ($out['deadline_utc'] !== 0 && $out['deadline_utc'] <= time()) {
                $out['deadline_utc'] = time() + 1800;
            }
        } else {
            // 'hourly' không dùng deadline cố định; giữ key để tránh notice
            $out['deadline_utc'] = isset($input['deadline_utc']) ? intval($input['deadline_utc']) : 0;
        }

        // Nền/hiển thị
        $out['bg_type']  = (isset($input['bg_type']) && in_array($input['bg_type'], ['solid','linear','radial'], true)) ? $input['bg_type'] : 'solid';
        $out['bg_color'] = isset($input['bg_color']) ? sanitize_hex_color($input['bg_color']) : '#111827';
        if (empty($out['bg_color'])) $out['bg_color'] = '#111827';

        $gc2 = isset($input['gradient_color_2']) ? sanitize_hex_color($input['gradient_color_2']) : '#1F2937';
        $out['gradient_color_2'] = $gc2 ?: '#1F2937';

        $out['gradient_angle'] = isset($input['gradient_angle']) ? intval($input['gradient_angle']) : 90;

        $tc = isset($input['text_color']) ? sanitize_hex_color($input['text_color']) : '#FFFFFF';
        $out['text_color'] = $tc ?: '#FFFFFF';

        $out['font_size_desktop'] = isset($input['font_size_desktop']) ? intval($input['font_size_desktop']) : 14;
        $out['font_size_mobile']  = isset($input['font_size_mobile'])  ? intval($input['font_size_mobile'])  : 12;

        $out['padding'] = isset($input['padding']) ? floatval($input['padding']) : 0.6;

        $out['position'] = (isset($input['position']) && in_array($input['position'], ['top','bottom'], true)) ? $input['position'] : 'top';
        $out['position_fixed'] = isset($input['position_fixed']) ? 1 : 0;

        // Đóng thanh
        $cm = isset($input['close_mode']) ? sanitize_text_field($input['close_mode']) : 'none';
        $out['close_mode'] = in_array($cm, ['none','session','permanent'], true) ? $cm : 'none';
        $out['close_duration'] = isset($input['close_duration']) ? intval($input['close_duration']) : 3600;

        return $out;
    }

    /**
     * Parse "datetime-local" (theo UTC+7 Asia/Bangkok) sang timestamp UTC.
     * Ví dụ: 2025-10-18T15:30 ← hiểu là 15:30 tại UTC+7.
     */
    private function parse_local_utc7_to_utc_ts($datetime_local) {
        if (empty($datetime_local)) return 0;
        try {
            $tz = new DateTimeZone('Asia/Bangkok'); // UTC+7
            $dt = new DateTime($datetime_local, $tz);
            return $dt->setTimezone(new DateTimeZone('UTC'))->getTimestamp();
        } catch (Exception $e) {
            return 0;
        }
    }

    private function get_local_utc7_value($utc_ts) {
        if (!$utc_ts) return '';
        $tz = new DateTimeZone('Asia/Bangkok');
        $dt = (new DateTime('@'.$utc_ts))->setTimezone($tz);
        return $dt->format('Y-m-d\TH:i');
    }

    /* ------------------- Settings UI ------------------- */
    public function settings_page_html() {
        if ( ! current_user_can('manage_options') ) return;
        $opt = get_option(self::OPT_KEY, []);
        $deadline_local = $this->get_local_utc7_value( (int)($opt['deadline_utc'] ?? 0) );
        $time_mode = $opt['time_mode'] ?? 'fixed';
        ?>
        <div class="wrap">
            <h1>Sticky Countdown Bar</h1>
            <form method="post" action="options.php">
                <?php settings_fields(self::OPT_KEY); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Bật thanh sticky</th>
                        <td><label>
                            <input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[enabled]" <?php checked(!empty($opt['enabled'])); ?> />
                            Kích hoạt hiển thị trên toàn site (Auto). Shortcode vẫn hiển thị khi Auto tắt.
                        </label></td>
                    </tr>

                    <tr>
                        <th scope="row">Text hiển thị</th>
                        <td><input type="text" class="regular-text" required
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[text]"
                                   value="<?php echo esc_attr($opt['text'] ?? ''); ?>"></td>
                    </tr>

                    <tr>
                        <th scope="row">URL của link</th>
                        <td><input type="url" class="regular-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[url]"
                                   value="<?php echo esc_attr($opt['url'] ?? ''); ?>"></td>
                    </tr>

                    <tr>
                        <th scope="row">Chế độ thời gian</th>
                        <td>
                            <label>
                                <input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[time_mode]" value="fixed" <?php checked($time_mode, 'fixed'); ?> />
                                Đến một ngày/giờ cụ thể (UTC+7)
                            </label>
                            <br>
                            <label>
                                <input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[time_mode]" value="hourly" <?php checked($time_mode, 'hourly'); ?> />
                                Luôn đếm tới đầu giờ tiếp theo (UTC+7)
                            </label>
                            <p class="description">Chọn <strong>hourly</strong> để thanh luôn đếm lùi tới mốc HH:00 kế tiếp (giờ Việt Nam).</p>
                        </td>
                    </tr>

                    <tr id="scb-deadline-row" style="<?php echo ($time_mode === 'fixed') ? '' : 'display:none;'; ?>">
                        <th scope="row">Đếm ngược tới</th>
                        <td>
                            <input type="datetime-local"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[deadline_local]"
                                   value="<?php echo esc_attr($deadline_local); ?>">
                            <p class="description">Theo múi giờ: <code>UTC+7 (Asia/Bangkok)</code></p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Loại nền</th>
                        <td>
                            <select name="<?php echo esc_attr(self::OPT_KEY); ?>[bg_type]" id="scb-bg-type">
                                <option value="solid"  <?php selected($opt['bg_type'] ?? 'solid',  'solid');  ?>>Màu đơn</option>
                                <option value="linear" <?php selected($opt['bg_type'] ?? '',       'linear'); ?>>Gradient tuyến tính</option>
                                <option value="radial" <?php selected($opt['bg_type'] ?? '',       'radial'); ?>>Gradient xuyên tâm</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Màu nền chính</th>
                        <td><input type="text" class="scb-color-picker regular-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[bg_color]"
                                   value="<?php echo esc_attr($opt['bg_color'] ?? '#111827'); ?>"
                                   data-default-color="#111827"></td>
                    </tr>

                    <tr id="scb-gradient-row" style="<?php echo ($opt['bg_type'] ?? 'solid') === 'solid' ? 'display:none;' : ''; ?>">
                        <th scope="row">Màu gradient thứ 2</th>
                        <td><input type="text" class="scb-color-picker regular-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[gradient_color_2]"
                                   value="<?php echo esc_attr($opt['gradient_color_2'] ?? '#1F2937'); ?>"
                                   data-default-color="#1F2937"></td>
                    </tr>

                    <tr id="scb-angle-row" style="<?php echo ($opt['bg_type'] ?? 'solid') === 'linear' ? '' : 'display:none;'; ?>">
                        <th scope="row">Góc gradient (tuyến tính)</th>
                        <td><input type="number" min="0" max="360" class="small-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[gradient_angle]"
                                   value="<?php echo esc_attr($opt['gradient_angle'] ?? 90); ?>">
                            <p class="description">0–360° (0=trên→dưới, 90=trái→phải, 180=dưới→trên, 270=phải→trái)</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Màu chữ</th>
                        <td><input type="text" class="scb-color-picker regular-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[text_color]"
                                   value="<?php echo esc_attr($opt['text_color'] ?? '#FFFFFF'); ?>"
                                   data-default-color="#FFFFFF"></td>
                    </tr>

                    <tr>
                        <th scope="row">Kích cỡ chữ (Desktop)</th>
                        <td><input type="number" min="10" max="32" class="small-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[font_size_desktop]"
                                   value="<?php echo esc_attr($opt['font_size_desktop'] ?? 14); ?>"> px</td>
                    </tr>

                    <tr>
                        <th scope="row">Kích cỡ chữ (Mobile)</th>
                        <td><input type="number" min="10" max="32" class="small-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[font_size_mobile]"
                                   value="<?php echo esc_attr($opt['font_size_mobile'] ?? 12); ?>"> px</td>
                    </tr>

                    <tr>
                        <th scope="row">Padding</th>
                        <td><input type="number" min="0" max="2" step="0.1" class="small-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[padding]"
                                   value="<?php echo esc_attr($opt['padding'] ?? 0.6); ?>"> rem</td>
                    </tr>

                    <!-- UI vị trí đang ẩn, nhưng vẫn hỗ trợ qua code (position, position_fixed) -->

                    <tr>
                        <th scope="row">Cho phép đóng thanh</th>
                        <td>
                            <fieldset>
                                <legend class="screen-reader-text">Cho phép đóng thanh</legend>
                                <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[close_mode]" value="none"      <?php checked(($opt['close_mode'] ?? 'none'), 'none'); ?> /> Không cho phép đóng</label><br>
                                <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[close_mode]" value="session"   <?php checked(($opt['close_mode'] ?? 'none'), 'session'); ?> /> Đóng trang hiện tại (load lại sẽ hiện)</label><br>
                                <label><input type="radio" name="<?php echo esc_attr(self::OPT_KEY); ?>[close_mode]" value="permanent" <?php checked(($opt['close_mode'] ?? 'none'), 'permanent'); ?> /> Đóng vĩnh viễn theo thời gian</label>
                                <p class="description">Chọn cách xử lý khi người dùng bấm nút đóng.</p>
                            </fieldset>
                        </td>
                    </tr>

                    <tr id="scb-duration-row" style="<?php echo (($opt['close_mode'] ?? 'none') === 'permanent') ? '' : 'display:none;'; ?>">
                        <th scope="row">Thời gian ẩn (chế độ vĩnh viễn)</th>
                        <td><input type="number" min="300" max="86400" class="small-text"
                                   name="<?php echo esc_attr(self::OPT_KEY); ?>[close_duration]"
                                   value="<?php echo esc_attr($opt['close_duration'] ?? 3600); ?>"> giây
                            <p class="description">Mặc định 3600 (1 giờ). Chỉ áp dụng khi chế độ là “vĩnh viễn”.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <!-- <h2>Ý tưởng dev shortcode</h2>
            <p>Dùng <code>[sticky_countdown_bar]</code> để chèn thanh vào vị trí bạn muốn. Shortcode <strong>không phụ thuộc</strong> vào “Bật thanh sticky (Auto)”.</p> -->
        </div>
        <?php
    }

    /* ------------------- Public enqueue (AUTO) ------------------- */
    public function enqueue_assets_auto() {
        $opt = get_option(self::OPT_KEY, []);
        if ( empty($opt['enabled']) ) return;

        if ( ! $this->should_show_now($opt) ) return;

        $this->enqueue_front_assets_with_vars($opt);
    }

    public function render_bar_auto() {
        $opt = get_option(self::OPT_KEY, []);
        if ( empty($opt['enabled']) ) return;
        if ( ! $this->should_show_now($opt) ) return;

        echo $this->render_bar_markup($opt);
    }

    /* ------------------- Shortcode ------------------- */
    public function shortcode($atts) {
        $opt = get_option(self::OPT_KEY, []);

        // Shortcode luôn cố gắng hiển thị nếu:
        // - mode = hourly: luôn bật
        // - mode = fixed: còn hạn
        if ( ! $this->should_show_now($opt, true) ) return '';

        // Tự enqueue khi shortcode dùng (kể cả Auto tắt)
        $this->enqueue_front_assets_with_vars($opt);

        return $this->render_bar_markup($opt);
    }

    /* ------------------- Helpers ------------------- */

    // Quyết định có hiển thị thời điểm hiện tại hay không
    private function should_show_now($opt, $force = false) {
        $mode = $opt['time_mode'] ?? 'fixed';
        if ($mode === 'hourly') {
            // Hourly: luôn hiển thị (JS sẽ tự tính mốc HH:00 kế tiếp)
            return true;
        }
        // Fixed: phải còn hạn
        $deadline = isset($opt['deadline_utc']) ? (int)$opt['deadline_utc'] : 0;
        if ( ! $deadline ) return false;
        return time() < $deadline;
    }

    // Enqueue CSS/JS + localize biến cấu hình
    private function enqueue_front_assets_with_vars($opt) {
        wp_enqueue_style('scb-style', plugin_dir_url(__FILE__) . 'assets/css/bar.css', [], self::VERSION);
        wp_enqueue_script('scb-script', plugin_dir_url(__FILE__) . 'assets/js/bar.js', [], self::VERSION, true);

        $font_size_desktop = intval($opt['font_size_desktop'] ?? 14);
        $font_size_mobile  = intval($opt['font_size_mobile'] ?? 12);
        $padding           = floatval($opt['padding'] ?? 0.6);
        $close_mode        = $opt['close_mode'] ?? 'session';

        $position       = $opt['position'] ?? 'top';
        $position_fixed = !empty($opt['position_fixed']);

        wp_localize_script('scb-script', 'SCB_DATA', [
            'timeMode'        => $opt['time_mode'] ?? 'fixed',
            'deadlineUtc'     => (int)($opt['deadline_utc'] ?? 0) * 1000,
            'tzOffsetMs'      => 7 * 3600 * 1000, // UTC+7
            'closeMode'       => $close_mode,
            'closeDuration'   => intval($opt['close_duration'] ?? 3600) * 1000,
            'fontSizeDesktop' => $font_size_desktop,
            'fontSizeMobile'  => $font_size_mobile,
            'padding'         => $padding,
            'position'        => $position,
            'positionFixed'   => $position_fixed,
        ]);

        // CSS động (nền + text + font)
        wp_add_inline_style('scb-style', $this->get_dynamic_css($opt));
    }

    // Markup thanh bar + spacer
    private function render_bar_markup($opt) {
        $text = esc_html($opt['text'] ?? '');
        $url  = isset($opt['url']) && $opt['url'] ? esc_url($opt['url']) : '';
        $close_mode = $opt['close_mode'] ?? 'session';

        // Lớp vị trí
        $pos_class = ($opt['position'] ?? 'top') === 'bottom' ? 'scb-bottom' : 'scb-top';
        $fixed_class = !empty($opt['position_fixed']) ? 'scb-fixed' : 'scb-notfixed';

        ob_start();
        echo '<div id="scb-sticky-bar" class="scb-ready ' . esc_attr($pos_class . ' ' . $fixed_class) . '" role="region" aria-label="Countdown Announcement">';
            echo '<div class="scb-content">';
                if ($url) {
                    echo '<a class="scb-link" href="' . $url . '">' . $text . '</a>';
                } else {
                    echo '<span class="scb-text">' . $text . '</span>';
                }
                echo ' <span class="scb-countdown" aria-live="polite"></span>';
            echo '</div>';
            if ($close_mode !== 'none') {
                echo '<button type="button" class="scb-close-btn" aria-label="Đóng thông báo" title="Đóng">&times;</button>';
            }
        echo '</div>';
        // Spacer chỉ cần khi top + fixed để đẩy nội dung
        echo '<div id="scb-spacer"></div>';
        return ob_get_clean();
    }

    // CSS động dựa theo tùy chọn nền/màu/kích thước
    private function get_dynamic_css($opt) {
        $text_color = esc_attr($opt['text_color'] ?? '#FFFFFF');
        $font_size_desktop = intval($opt['font_size_desktop'] ?? 14);
        $font_size_mobile  = intval($opt['font_size_mobile'] ?? 12);
        $padding           = floatval($opt['padding'] ?? 0.6);

        $bg_css = $this->get_gradient_css($opt);

        return <<<CSS
#scb-sticky-bar {
  {$bg_css}
  color: {$text_color};
  font-size: {$font_size_desktop}px;
  padding: {$padding}rem .9rem;
}
@media (max-width: 480px){
  #scb-sticky-bar { font-size: {$font_size_mobile}px; }
}
CSS;
    }

    private function get_gradient_css($opt) {
        $bg  = esc_attr($opt['bg_color'] ?? '#111827');
        $g2  = esc_attr($opt['gradient_color_2'] ?? '#1F2937');
        $ang = intval($opt['gradient_angle'] ?? 90);

        switch ($opt['bg_type'] ?? 'solid') {
            case 'linear':
                return "background: linear-gradient({$ang}deg, {$bg}, {$g2});";
            case 'radial':
                return "background: radial-gradient(circle, {$bg}, {$g2});";
            case 'solid':
            default:
                return "background-color: {$bg};";
        }
    }
}

new Sticky_Countdown_Bar();
